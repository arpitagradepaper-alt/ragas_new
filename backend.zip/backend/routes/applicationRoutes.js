const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const mongoose = require("mongoose");

const Application = require("../models/Application");
const Job = require("../models/Job");
const {
  authMiddleware,
  adminMiddleware,
  partnerMiddleware,
} = require("../middleware/authMiddleware");

const router = express.Router();

// =====================================================
// UPLOAD DIRECTORY
// Persisted next to the backend (survives restarts and
// redeploys) instead of /tmp which is wiped on reboot.
// =====================================================

const uploadDir = path.join(
  __dirname,
  "..",
  "uploads",
  "applications"
);

if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, {
    recursive: true,
  });
}

// =====================================================
// MULTER STORAGE
// =====================================================

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },

  filename: (req, file, cb) => {
    const uniqueName =
      `${Date.now()}-${Math.round(
        Math.random() * 1e9
      )}${path.extname(file.originalname)}`;

    // Keep the candidate's original file name so the
    // admin panel can show/serve it with a proper name.
    req.savedOriginalFileName = file.originalname;

    cb(null, uniqueName);
  },
});

// =====================================================
// FILE FILTER
// =====================================================

const fileFilter = (req, file, cb) => {
  const allowedExtensions = [
    ".pdf",
    ".doc",
    ".docx",
  ];

  const extension =
    path.extname(file.originalname).toLowerCase();

  if (!allowedExtensions.includes(extension)) {
    return cb(
      new Error(
        "Only PDF, DOC and DOCX files are allowed."
      )
    );
  }

  cb(null, true);
};

// =====================================================
// MULTER
// =====================================================

const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 10 * 1024 * 1024,
  },
});

// =====================================================
// CREATE APPLICATION
// =====================================================

router.post(
  "/",
  upload.single("resume"),
  async (req, res) => {
    try {
      const {
        jobId,
        jobTitle,
        fullName,
        email,
        phone,
        dateOfBirth,
        currentLocation,
        currentJobTitle,
        totalExperience,
        highestQualification,
        currentCompany,
        keySkills,
        preferredLocation,
        preferredCountry,
        expectedSalary,
        noticePeriod,
        coverLetter,
      } = req.body;

      let partnerId = null;
      let actualJobTitle = jobTitle;

      // =================================================
      // FIND JOB
      // =================================================

      if (
        jobId &&
        mongoose.Types.ObjectId.isValid(jobId)
      ) {
        const job = await Job.findById(jobId);

        if (job) {
          partnerId = job.partnerId || null;

          actualJobTitle =
            job.jobTitle || actualJobTitle;
        }
      }

      // =================================================
      // REQUIRED FIELDS
      // =================================================

      if (
        !jobId ||
        !jobTitle ||
        !fullName ||
        !email ||
        !phone
      ) {
        return res.status(400).json({
          success: false,
          message:
            "Job, name, email and phone are required.",
        });
      }

      // =================================================
      // RESUME REQUIRED
      // =================================================

      if (!req.file) {
        return res.status(400).json({
          success: false,
          message:
            "Please upload your resume.",
        });
      }

      // =================================================
      // NORMALIZE EMAIL
      // =================================================

      const normalizedEmail =
        String(email)
          .trim()
          .toLowerCase();

      // =================================================
      // OPTIONAL USER LINK (logged-in job seekers send a
      // token; guest applicants may not)
      // =================================================

      let submittingUserId = null;

      if (
        req.headers.authorization &&
        req.headers.authorization.startsWith("Bearer ")
      ) {
        try {
          const jwt = require("jsonwebtoken");

          const decoded = jwt.verify(
            req.headers.authorization.split(" ")[1],
            process.env.JWT_SECRET
          );

          if (decoded && decoded.id) {
            submittingUserId = decoded.id;
          }
        } catch (tokenError) {
          // Invalid/expired token - treat as guest applicant
          submittingUserId = null;
        }
      }

      // =================================================
      // CREATE APPLICATION
      // =================================================

      const application =
        new Application({
          partnerId,

          jobId,

          user: submittingUserId || null,

          originalFileName:
            req.savedOriginalFileName || "",

          jobTitle:
            actualJobTitle,

          fullName,

          email:
            normalizedEmail,

          phone,

          dateOfBirth,

          currentLocation,

          currentJobTitle,

          totalExperience,

          highestQualification,

          currentCompany,

          keySkills,

          preferredLocation,

          preferredCountry,

          expectedSalary,

          noticePeriod,

          coverLetter,

          resumeFile:
            req.file.filename,

          originalFileName:
            req.file.originalname,

          status: "Applied",
        });

      await application.save();

      return res.status(201).json({
        success: true,

        message:
          "Application submitted successfully.",

        data: application,
      });
    } catch (error) {
      console.error(
        "CREATE APPLICATION ERROR:",
        error
      );

      return res.status(500).json({
        success: false,

        message:
          error.message ||
          "Unable to submit application.",
      });
    }
  }
);

// =====================================================
// GET ALL APPLICATIONS (ADMIN ONLY)
// =====================================================

router.get("/", authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const applications =
      await Application.find()
        .sort({
          createdAt: -1,
        });

    return res.json({
      success: true,
      data: applications,
    });
  } catch (error) {
    console.error(
      "GET APPLICATIONS ERROR:",
      error
    );

    return res.status(500).json({
      success: false,

      message:
        "Unable to load applications.",
    });
  }
});

// =====================================================
// GET APPLICATIONS FOR CURRENT CANDIDATE
// =====================================================

router.get(
  "/candidate",
  authMiddleware,
  async (req, res) => {
    try {
      const { email } = req.query;

      // -----------------------------------------------
      // EMAIL REQUIRED
      // -----------------------------------------------

      if (!email) {
        return res.status(400).json({
          success: false,

          message:
            "Candidate email is required.",
        });
      }

      // -----------------------------------------------
      // NORMALIZE EMAIL
      // -----------------------------------------------

      const normalizedEmail =
        String(email)
          .trim()
          .toLowerCase();

      // -----------------------------------------------
      // OWNERSHIP CHECK
      // A logged-in user may only read the
      // applications submitted with their own email.
      // -----------------------------------------------

      if (req.user.email !== normalizedEmail) {
        return res.status(403).json({
          success: false,

          message:
            "You can only view your own applications.",
        });
      }

      // -----------------------------------------------
      // FIND APPLICATIONS
      // -----------------------------------------------

      const applications =
        await Application.find({
          email: normalizedEmail,
        }).sort({
          createdAt: -1,
        });

      // -----------------------------------------------
      // RESPONSE
      // -----------------------------------------------

      return res.json({
        success: true,

        data: applications,
      });
    } catch (error) {
      console.error(
        "GET CANDIDATE APPLICATIONS ERROR:",
        error
      );

      // IMPORTANT:
      // Return actual error so we can identify
      // the problem on live server.

      return res.status(500).json({
        success: false,

        message:
          error.message ||
          "Unable to load candidate applications.",

        error:
          error.stack || null,
      });
    }
  }
);

// =====================================================
// RESUME
// IMPORTANT: THIS MUST COME BEFORE /:id
// =====================================================

router.get(
  "/resume/:filename",
  (req, res) => {
    try {
      const filename =
        path.basename(
          req.params.filename
        );

      const filePath =
        path.join(
          uploadDir,
          filename
        );

      if (!fs.existsSync(filePath)) {
        return res.status(404).json({
          success: false,

          message:
            "Resume file not found.",
        });
      }

      return res.sendFile(filePath);
    } catch (error) {
      console.error(
        "RESUME ERROR:",
        error
      );

      return res.status(500).json({
        success: false,

        message:
          "Unable to open resume.",
      });
    }
  }
);

// =====================================================
// GET SINGLE APPLICATION (ADMIN ONLY)
// =====================================================

router.get(
  "/:id",
  authMiddleware,
  adminMiddleware,
  async (req, res) => {
    try {
      const application =
        await Application.findById(
          req.params.id
        );

      if (!application) {
        return res.status(404).json({
          success: false,

          message:
            "Application not found.",
        });
      }

      return res.json({
        success: true,

        data: application,
      });
    } catch (error) {
      console.error(
        "GET SINGLE APPLICATION ERROR:",
        error
      );

      return res.status(500).json({
        success: false,

        message:
          "Unable to load application.",
      });
    }
  }
);

// =====================================================
// UPDATE APPLICATION STATUS (ADMIN ONLY)
// =====================================================

router.patch(
  "/:id/status",
  authMiddleware,
  adminMiddleware,
  async (req, res) => {
    try {
      const { status } = req.body;

      const allowedStatuses = [
        "Applied",
        "Under Review",
        "Shortlisted",
        "Interview",
        "Selected",
        "Rejected",
      ];

      // -----------------------------------------------
      // STATUS REQUIRED
      // -----------------------------------------------

      if (!status) {
        return res.status(400).json({
          success: false,

          message:
            "Application status is required.",
        });
      }

      // -----------------------------------------------
      // VALIDATE STATUS
      // -----------------------------------------------

      if (
        !allowedStatuses.includes(
          status
        )
      ) {
        return res.status(400).json({
          success: false,

          message:
            "Invalid application status.",
        });
      }

      // -----------------------------------------------
      // UPDATE
      // -----------------------------------------------

      const application =
        await Application.findByIdAndUpdate(
          req.params.id,

          {
            status,
          },

          {
            new: true,
            runValidators: true,
          }
        );

      if (!application) {
        return res.status(404).json({
          success: false,

          message:
            "Application not found.",
        });
      }

      return res.json({
        success: true,

        message:
          "Application status updated successfully.",

        data: application,
      });
    } catch (error) {
      console.error(
        "UPDATE APPLICATION STATUS ERROR:",
        error
      );

      return res.status(500).json({
        success: false,

        message:
          "Unable to update application status.",
      });
    }
  }
);

// =====================================================
// MULTER / ROUTE ERROR HANDLER
// =====================================================

router.use(
  (error, req, res, next) => {
    console.error(
      "APPLICATION ROUTE ERROR:",
      error
    );

    if (
      error instanceof multer.MulterError
    ) {
      if (
        error.code ===
        "LIMIT_FILE_SIZE"
      ) {
        return res.status(400).json({
          success: false,

          message:
            "Resume must be 5 MB or smaller.",
        });
      }

      return res.status(400).json({
        success: false,

        message:
          error.message ||
          "Resume upload failed.",
      });
    }

    return res.status(400).json({
      success: false,

      message:
        error.message ||
        "Application request failed.",
    });
  }
);

module.exports = router;